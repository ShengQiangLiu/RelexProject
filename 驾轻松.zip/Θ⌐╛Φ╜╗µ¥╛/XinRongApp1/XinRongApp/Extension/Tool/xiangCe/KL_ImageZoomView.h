//
//  KL_ImageZoomView.h
//  XinRongApp
//
//  Created by lidongqiang on 15-6-26.
//  Copyright (c) 2014年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "DDProgressView/DDProgressView.h"
//#import "SDWebImage/SDWebImageManager.h"
//#import "SDWebImageManagerDelegate.h"
//#import "SDWebImageManager.h"

@interface KL_ImageZoomView : UIView <UIScrollViewDelegate,SDWebImageManagerDelegate>
{
    CGFloat viewscale;
    NSString *downImgUrl;
    
}
@property (nonatomic, retain) UIScrollView *scrollView;
@property (nonatomic, retain) UIImageView *imageView;
@property (nonatomic, retain) UIImage *image;
@property (nonatomic, assign) BOOL isViewing;
@property (nonatomic, retain)UIView *containerView;
//@property (nonatomic, retain)DDProgressView *progress;

- (void)resetViewFrame:(CGRect)newFrame;
- (void)updateImage:(NSString *)imgName;
- (void)uddateImageWithUrl:(NSString *)imgUrl;

@end
