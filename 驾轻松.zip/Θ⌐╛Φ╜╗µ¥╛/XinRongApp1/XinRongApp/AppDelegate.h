//
//  AppDelegate.h
//  XinRongApp
//
//  Created by 李冬强 on 15/3/9.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

