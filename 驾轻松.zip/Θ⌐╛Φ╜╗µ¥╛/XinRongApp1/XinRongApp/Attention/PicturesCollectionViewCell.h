//
//  PicturesCollectionViewCell.h
//  XinRongApp
//
//  Created by 李冬强 on 15/4/14.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PicturesCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *imgNameLab;

@end
