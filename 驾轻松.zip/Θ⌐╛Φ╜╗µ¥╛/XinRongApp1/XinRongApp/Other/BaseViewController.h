//
//  BaseViewController.h
//  生活荟
//
//  Created by 李冬强 on 15-1-20.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "MBProgressHUD.h"
//#import "AFNetworking.h"
@interface BaseViewController : UIViewController
//@property (nonatomic, strong) MBProgressHUD *HUD;

@end
