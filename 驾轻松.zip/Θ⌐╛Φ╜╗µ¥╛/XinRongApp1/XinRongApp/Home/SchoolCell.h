//
//  SchoolCell.h
//  驾轻松
//
//  Created by 李冬强 on 15/7/21.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SchoolCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imagView;
@property (weak, nonatomic) IBOutlet UILabel *jiaXiaoName;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *detailAddress;

@end
