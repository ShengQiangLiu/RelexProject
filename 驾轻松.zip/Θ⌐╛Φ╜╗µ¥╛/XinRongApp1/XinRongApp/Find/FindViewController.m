//
//  FindViewController.m
//  新融网
//
//  Created by 李冬强 on 15/7/17.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "FindViewController.h"
#import "TableHead.h"
#import "StoryboardCell.h"
#import "StoryboardViewController.h"
@interface FindViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@end

@implementation FindViewController
- (id)initWithTitle:(NSString *)title withNavigationTitle:(NSString *)navTitle {
    
    if (self=[super init]) {
        // Custom initialization
        [[self tabBarItem] setImage:[UIImage imageNamed:@"findIcon.png"]];
        
        self.title = title;
        self.navigationItem.title = navTitle;
        
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = KLColor(246, 246, 246);
    [self addTableView];
}

#pragma mark -添加列表视图
- (void)addTableView
{
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 20, kWidth, kHeight-20) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = KLColor(246, 246, 246);
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [self.view addSubview:_tableView];
}

#pragma mark - 根据文字获取视图大小
- (CGRect)getSizeWithString:(NSString *)string andFont:(CGFloat)font
{
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.lineBreakMode = NSLineBreakByWordWrapping;
    style.alignment = NSTextAlignmentCenter;
    style.lineSpacing = 10;// 字体的行间距
    NSDictionary *dict = @{NSFontAttributeName:[UIFont systemFontOfSize:font],NSForegroundColorAttributeName:[UIColor grayColor],
                           NSParagraphStyleAttributeName:style.copy};
    //    CGSize size = [string sizeWithAttributes:dict];
    
    // 计算文字在指定最大宽和高下的真实大小
    // 1000 表示高度不限制
    CGRect rect = [string boundingRectWithSize:CGSizeMake(_tableView.width-30, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:dict context:NULL];
    return rect;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *const identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    UIImage *icon = [UIImage imageNamed:@"find_gsb.png"];
    CGSize iconSize = CGSizeMake(30, 30);
    UIGraphicsBeginImageContextWithOptions(iconSize, NO, 0.0);
    CGRect rect = CGRectMake(0, 0, iconSize.width, iconSize.height);
    [icon drawInRect:rect];
    cell.imageView.image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    //箭头
    UIImage *jianTouImg = [UIImage imageNamed:@"jianTou.png"];
    UIImageView *jianTimgView = [[UIImageView alloc]initWithImage:jianTouImg];
    jianTimgView.frame = CGRectMake(0, 0, jianTouImg.size.width/2, jianTouImg.size.height/2);
    cell.accessoryView = jianTimgView;
    cell.textLabel.text = @"故事板";

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //391*268
    return 55;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    StoryboardViewController *storyboardVC = [[StoryboardViewController alloc]init];
    [self.navigationController pushViewController:storyboardVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
