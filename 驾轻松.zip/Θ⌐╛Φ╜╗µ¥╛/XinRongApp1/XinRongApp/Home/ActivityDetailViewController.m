//
//  ActivityDetailViewController.m
//  驾轻松
//
//  Created by 李冬强 on 15/7/20.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "ActivityDetailViewController.h"
#import "ActivityDetailCell.h"
@interface ActivityDetailViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIView *detailViewBgView;
@end

#define space 5

@implementation ActivityDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"活动详情";
    [self addSubview];
}

- (void)addSubview
{
    //    self.view.backgroundColor = [UIColor whiteColor];
    //    _detailViewBgView = [[UIView alloc]init];
    //白色圆角背景
    _detailViewBgView = [[UIView alloc]initWithFrame:CGRectMake(0, kNavigtBarH, kWidth, kHeight-kNavigtBarH)];
    _detailViewBgView.backgroundColor = [UIColor whiteColor];

    
    NSString *string;
        string= @"    本息保障-为您的投资保驾护航1.A种方式120元/年，对发生逾期后的本金及利息进行垫付最高垫付额为人民币10万元2.B种方式200元/年，对发生逾期后的本金及利息进行垫付无最高垫付额\n3.两种方式之间独立，不可补交升级。对于加入了A计划的用户，想要加入B计划时只能重新购买";
    CGFloat fontSize = 13;
    
    //titleLab
    UILabel *titleLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, kWidth, 30)];
    titleLab.text = @"活动名称";
    titleLab.textColor = KLColor_ox(0x3e3a39);
    titleLab.textAlignment = NSTextAlignmentCenter;
    titleLab.font = [UIFont systemFontOfSize:16];
    [_detailViewBgView addSubview:titleLab];
    
    //timeLab
    UILabel *timeLab = [[UILabel alloc]initWithFrame:CGRectMake(0, titleLab.bottom+kHScare(5), kWidth, 30)];
    timeLab.text = @"2015-07-09";
    timeLab.textAlignment = NSTextAlignmentCenter;
    timeLab.textColor = KLColor_ox(0x9fa0a0);
    timeLab.font = [UIFont systemFontOfSize:11];
    timeLab.textColor = [UIColor grayColor];
    [_detailViewBgView addSubview:timeLab];
    
    UILabel *lab = [[UILabel alloc]init];
    lab.numberOfLines = 0;
    lab.textColor = KLColor_ox(0x3e3a39);
    CGRect frame = [self getSizeWithString:string andFont:fontSize];
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.lineSpacing = 5;// 字体的行间距
    NSDictionary *dict = @{NSFontAttributeName:[UIFont systemFontOfSize:fontSize],NSForegroundColorAttributeName:[UIColor grayColor],
                           NSParagraphStyleAttributeName:style.copy};
    lab.frame = CGRectMake(kWScare(5), timeLab.bottom+kHScare(5), _detailViewBgView.width-2*kWScare(5), frame.size.height);
    lab.font = [UIFont systemFontOfSize:fontSize];
    lab.attributedText = [[NSAttributedString alloc] initWithString:string attributes:dict];;
    
    //msgType
    UILabel *msgType = [[UILabel alloc]initWithFrame:CGRectMake(kWScare(5), lab.bottom+kHScare(5), 180, 30)];
    msgType.text = @"报名截止：2015-9-12";
    msgType.textColor = KLColor_ox(0x3e3a39);
    msgType.font = [UIFont systemFontOfSize:fontSize];
    [_detailViewBgView addSubview:msgType];
    //cMsgType
    UILabel *cMsgType = [[UILabel alloc]initWithFrame:CGRectMake(kWScare(5), msgType.bottom+kHScare(5), 180, 30)];
    cMsgType.text = @"电话：15578788787";
    cMsgType.textColor = KLColor_ox(0x3e3a39);
    cMsgType.font = [UIFont systemFontOfSize:fontSize];
    [_detailViewBgView addSubview:cMsgType];
    
    //    lab.backgroundColor = [UIColor redColor];
    [_detailViewBgView addSubview:lab];
    
    _detailViewBgView.frame = CGRectMake(0, kNavigtBarH, kWidth, cMsgType.bottom);
    
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableHeaderView = _detailViewBgView;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [self.view addSubview:_tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    ActivityDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[NSBundle mainBundle] loadNibNamed:@"ActivityDetailCell" owner:self options:nil][0];
    }
    //    cell.imgView.image = [UIImage imageWithName:@""];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //391*268
    return 126;
}

//- (void)readedMessageRequest
//{
//    //    [SVProgressHUD showWithStatus:@"发送请求中..."];
//    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
//    [parameter setObject:_dataModel.msgId forKey:@"msgId"];
//    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc]init];
//    //https请求方式设置
//    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
//    securityPolicy.allowInvalidCertificates = YES;
//    manager.securityPolicy = securityPolicy;
//    //    __weak typeof(self) weakSelf = self;
//    [manager POST:kloadMessageUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        MyLog(@"%@",responseObject);
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        MyLog(@"%@",error);
//    }];
//}

#pragma mark - 根据文字获取视图大小
- (CGRect)getSizeWithString:(NSString *)string andFont:(CGFloat)font
{
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.lineBreakMode = NSLineBreakByWordWrapping;
    style.alignment = NSTextAlignmentCenter;
    style.lineSpacing = 5;// 字体的行间距
    NSDictionary *dict = @{NSFontAttributeName:[UIFont systemFontOfSize:font],NSForegroundColorAttributeName:[UIColor grayColor],
                           NSParagraphStyleAttributeName:style.copy};
    //    NSDictionary *dict = @{NSFontAttributeName:[UIFont systemFontOfSize:font], NSParagraphStyleAttributeName:style.copy};
    //    CGSize size = [string sizeWithAttributes:dict];
    
    // 计算文字在指定最大宽和高下的真实大小
    // 1000 表示高度不限制
    CGRect rect = [string boundingRectWithSize:CGSizeMake(kWidth-2*kWScare(space), CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:dict context:NULL];
    return rect;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
