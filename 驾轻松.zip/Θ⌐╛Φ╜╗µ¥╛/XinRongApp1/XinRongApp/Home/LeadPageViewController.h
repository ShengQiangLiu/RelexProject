//
//  LeadPageViewController.h
//  XinRongApp
//
//  Created by 李冬强 on 15/5/21.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeadPageViewController : UIViewController

@end
