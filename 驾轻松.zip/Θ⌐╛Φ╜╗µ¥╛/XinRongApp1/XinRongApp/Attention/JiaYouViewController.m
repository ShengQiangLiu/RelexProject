//
//  JiaYouViewController.m
//  驾轻松
//
//  Created by 李冬强 on 15/7/19.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "JiaYouViewController.h"

@interface JiaYouViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *sectionMuArray;
@end

@implementation JiaYouViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    [self addTableView];
}

- (void)initData
{
    _sectionMuArray = [NSMutableArray arrayWithObjects:@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H", nil];
}

#pragma mark -添加列表视图
- (void)addTableView
{
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight-49-kNavigtBarH-42) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = KLColor(246, 246, 246);
    _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    [self.view addSubview:_tableView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 6;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return section*3+1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *const identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    UIImage *icon = [UIImage imageNamed:@"person.png"];
    CGSize iconSize = CGSizeMake(30, 30);
    UIGraphicsBeginImageContextWithOptions(iconSize, NO, 0.0);
    CGRect rect = CGRectMake(0, 0, iconSize.width, iconSize.height);
    [icon drawInRect:rect];
    cell.imageView.image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    cell.textLabel.textColor = KLColor_ox(0x3e3a39);
    cell.textLabel.font = [UIFont systemFontOfSize:16];
    cell.textLabel.text = @"驾友名";
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //391*268
    return 55;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return _sectionMuArray[section];
}

//- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
//{
////    NSMutableArray *arr = [[[NSMutableArray alloc] initWithCapacity:0] autorelease];
////    [arr addObject:@"{search}"];//等价于[arr addObject:UITableViewIndexSearch];
//    return _sectionMuArray;
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    StoryboardViewController *storyboardVC = [[StoryboardViewController alloc]init];
//    [self.navigationController pushViewController:storyboardVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
