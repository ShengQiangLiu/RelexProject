//
//  MyDetailViewController.m
//  驾轻松
//
//  Created by 李冬强 on 15/7/18.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "MyDetailViewController.h"
#import "PersonDetailView.h"
@interface MyDetailViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property (nonatomic ,strong) PersonDetailView *footView;
@end

@implementation MyDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"个人信息";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"编辑" style:UIBarButtonItemStyleDone target:self action:@selector(edit)];
    UITableView *tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight-kNavigtBarH) style:UITableViewStylePlain];
//    tableview.backgroundColor = KLColor(237, 239, 241);
    _footView = [PersonDetailView creatView];
    [_footView.iconBtn addTarget:self action:@selector(addUploadHeadClicked) forControlEvents:UIControlEventTouchUpInside];
    tableview.tableFooterView = _footView;
    [self.view addSubview:tableview];
}

- (void)edit
{
    _footView.nameTF.text = @"";
    _footView.iconTF.text = @"";
}

- (void)addUploadHeadClicked
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil, nil];
    [actionSheet addButtonWithTitle:@"拍照"];
    [actionSheet addButtonWithTitle:@"从手机相册选择"];
    // 同时添加一个取消按钮
    [actionSheet addButtonWithTitle:@"取消"];
    // 将取消按钮的index设置成我们刚添加的那个按钮，这样在delegate中就可以知道是那个按钮
    actionSheet.destructiveButtonIndex = actionSheet.numberOfButtons - 1;
    [actionSheet showInView:self.view];
}


#pragma mark - 判断设备是否有摄像头

- (BOOL)isCameraAvailable
{
    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
}


#pragma mark - UIActionSheet delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.editing = YES;
    imagePicker.allowsEditing = YES;
    imagePicker.delegate = self;
    
    if (buttonIndex == 0)//照相机
    {
        if ([self isCameraAvailable]) {
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentModalViewController:imagePicker animated:YES];
        }else{
            //            [PublicMethod showMBProgressHUD:@"该设备没有摄像头" andWhereView:self.view hiddenTime:kHiddenTime];
        }
    }
    if (buttonIndex == 1)
    {
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentModalViewController:imagePicker animated:YES];
    }
    if (buttonIndex == 2)
    {
        
    }
    //    [imagePicker release];
}

#pragma mark - UIImagePicker delegate

//- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
//{
//    [picker dismissModalViewControllerAnimated:YES];
//    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
//    [self performSelector:@selector(saveImage:) withObject:image afterDelay:0.5];
//}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *_selectedImage = [[UIImage alloc] init];
    _selectedImage = info[@"UIImagePickerControllerOriginalImage"];
    
    NSData *data = UIImageJPEGRepresentation(_selectedImage, 0.5);
    // 这里base64Encoding 要修改
    //    NSString *baseStr = [data base64Encoding];
    //    NSLog(@"%@",baseStr);
    [self dismissViewControllerAnimated:YES completion:^{
//        [self loadRequest:data];
    }];
    //    [self performSelector:@selector(loadRequest:) withObject:_selectedImage afterDelay:0.5];
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}

- (void)_back
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
