//
//  CommentViewController.h
//  驾轻松
//
//  Created by 李冬强 on 15/7/24.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "BaseViewController.h"

@interface CommentViewController : BaseViewController
- (IBAction)topBtnAct:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UILabel *allLab;
@property (weak, nonatomic) IBOutlet UILabel *allNum;
@property (weak, nonatomic) IBOutlet UILabel *goodLab;
@property (weak, nonatomic) IBOutlet UILabel *goodNum;
@property (weak, nonatomic) IBOutlet UILabel *badLab;
@property (weak, nonatomic) IBOutlet UILabel *badNum;

@end
