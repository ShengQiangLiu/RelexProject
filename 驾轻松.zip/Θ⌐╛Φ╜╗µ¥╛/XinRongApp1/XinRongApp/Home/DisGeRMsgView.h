//
//  DisGeRMsgView.h
//  驾轻松
//
//  Created by 李冬强 on 15/7/22.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DisGeRMsgView : UIView
+ (instancetype)creatView;
@end
