//
//  PicturesCollectionViewCell.m
//  XinRongApp
//
//  Created by 李冬强 on 15/4/14.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "PicturesCollectionViewCell.h"

@implementation PicturesCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
