//
//  PersonView.m
//  驾轻松
//
//  Created by 李冬强 on 15/7/18.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "PersonView.h"

@implementation PersonView
+ (instancetype)creatView
{
    // 简单写法
    return [[NSBundle mainBundle] loadNibNamed:@"PersonView" owner:self options:nil][0];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
