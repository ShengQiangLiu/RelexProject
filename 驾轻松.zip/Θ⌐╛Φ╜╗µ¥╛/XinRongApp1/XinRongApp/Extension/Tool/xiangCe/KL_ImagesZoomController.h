//
//  KL_ImagesZoomController.h
//  XinRongApp
//
//  Created by lidongqiang on 15-6-26.
//  Copyright (c) 2014年 ldq. All rights reserved.//

#import <UIKit/UIKit.h>

@interface KL_ImagesZoomController : UIView<UITableViewDelegate,UITableViewDataSource>
- (id)initWithFrame:(CGRect)frame imgViewSize:(CGSize)size;
@property (nonatomic, retain)NSArray *imgs;

- (void)updateImageDate:(NSArray *)imageArr selectIndex:(NSInteger)index;
@end
