//
//  MyselfViewController.m
//  新融网
//
//  Created by 李冬强 on 15/7/17.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "MyselfViewController.h"
#import "MyDetailViewController.h"
#import "PersonView.h"
#import <CoreLocation/CoreLocation.h>
#import "DZNSegmentedControl.h"
#import "CHTCollectionViewWaterfallLayout.h"
#import "SchoolCell.h"
#import "PingLunCell.h"
@interface MyselfViewController ()<UITableViewDataSource,UITableViewDelegate,UICollectionViewDataSource, UICollectionViewDelegate,CHTCollectionViewDelegateWaterfallLayout,CLLocationManagerDelegate>
@property (nonatomic, strong) NSArray *menuItems;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) PersonView *footView;
@property (nonatomic, assign) NSInteger segementIndex;
@property (nonatomic, strong) UIView *bottonView;
@property (nonatomic, strong) NSArray *sectionMuArray;
@end

#define kSegmentedControlHeight 34
#define kCollectionCellSpace 6
#define kPopViewH 300
static NSString *schoolCell = @"SchoolCell";

@implementation MyselfViewController
- (id)initWithTitle:(NSString *)title withNavigationTitle:(NSString *)navTitle {
    
    if (self=[super init]) {
        // Custom initialization
        [[self tabBarItem] setImage:[UIImage imageNamed:@"personIcon.png"]];
        
        self.title = title;
        self.navigationItem.title = navTitle;
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = KLColor(237, 239, 241);
    _footView = [PersonView creatView];
    [_footView.nextBtn addTarget:self action:@selector(goNext) forControlEvents:UIControlEventTouchUpInside];
//    tableview.tableFooterView = _footView;
    [self.view addSubview:_footView];
    _bottonView = [[UIView alloc]init];
    _bottonView.frame = CGRectMake(0, _footView.bottom, kWidth, kHeight-_footView.bottom);
//    _bottonView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_bottonView];
    [self initData];
    [self initSubView];
//    [self.view addSubview:btn];
}

- (void)initData
{
    _sectionMuArray = [NSMutableArray arrayWithObjects:@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H", nil];
    _menuItems = @[@"分享",@"图钉",@"粉丝",@"评论"];
}

- (void)goNext
{
    MyDetailViewController *mydetailVC = [[MyDetailViewController alloc]init];
    [self.navigationController pushViewController:mydetailVC animated:YES];
}

- (void)initSubView
{
    // 添加分段条
    [self addSegmentControl];
    
    // 添加tableview
    [self addTableView];
    
//     添加collectionwaterfalllayout
    [self addCollectionwaterfalllayout];
    
    // 注册tableviewCell nib
    UINib *nib = [UINib nibWithNibName:schoolCell bundle:nil];
//    [self.tableView registerNib:nib forCellReuseIdentifier:schoolCell];
    
    // 注册collectionView nib
    nib = [UINib nibWithNibName:schoolCell bundle:nil];
    [self.collectionView registerNib:nib forCellWithReuseIdentifier:schoolCell];

}

#pragma mark 添加分段条
- (void)addSegmentControl
{
    // 添加分段条
    DZNSegmentedControl *segmentedControl = [[DZNSegmentedControl alloc] initWithItems:self.menuItems];
    
    segmentedControl.height = kSegmentedControlHeight;
    segmentedControl.selectedSegmentIndex = 0;
    segmentedControl.bouncySelectionIndicator = YES;
    segmentedControl.tintColor = kZhuTiColor;
    segmentedControl.showsCount = NO;
    [segmentedControl setFont:[UIFont systemFontOfSize:8]];
    
    // 添加点击方法
    [segmentedControl addTarget:self action:@selector(selectedSegment:) forControlEvents:UIControlEventValueChanged];
    [self.bottonView addSubview:segmentedControl];
    
}

#pragma mark 添加tableview
- (void)addTableView
{
    // 添加
    UITableView *tableView = [[UITableView alloc]init];
    tableView.frame = CGRectMake(0, kSegmentedControlHeight, self.view.frame.size.width, _bottonView.height-kSegmentedControlHeight - kNavigtBarH-49);
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.backgroundColor = KLColor(237, 239, 241);
    tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
//    [_bottonView addSubview:tableView];
    self.tableView = tableView;
}

#pragma mark 添加collectionwaterfalllayout
- (void)addCollectionwaterfalllayout
{
    // 创建collectionView布局
    CHTCollectionViewWaterfallLayout *layout = [[CHTCollectionViewWaterfallLayout alloc] init];
    
    layout.sectionInset = UIEdgeInsetsMake(0, kCollectionCellSpace, kCollectionCellSpace, kCollectionCellSpace);
    
    layout.minimumColumnSpacing = kCollectionCellSpace;
    layout.minimumInteritemSpacing = kCollectionCellSpace;
    layout.columnCount = 2;
    
    UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:self.tableView.frame collectionViewLayout:layout];
    
    collectionView.delegate = self;
    collectionView.dataSource = self;
    collectionView.backgroundColor = [UIColor clearColor];
    [_bottonView addSubview:collectionView];
    self.collectionView = collectionView;
}

#pragma mark 分段条目点击方法
- (void)selectedSegment:(DZNSegmentedControl *)control
{
    MyLog(@"选择了第%ld项",(long)control.selectedSegmentIndex);
    
    _segementIndex = control.selectedSegmentIndex;
    // 设置导航条标题
    self.title = self.menuItems[control.selectedSegmentIndex];
    
    switch (control.selectedSegmentIndex)
    {
        case 0: //
        {
            if (self.collectionView.superview == nil) {
                [_bottonView addSubview:self.collectionView];
            }
            if (self.tableView.superview) {
                [_tableView removeFromSuperview];
            }
            break;
        }
        case 1: //
        {
            if (self.collectionView.superview == nil) {
                [_bottonView addSubview:self.collectionView];
            }
            if (self.tableView.superview) {
                [_tableView removeFromSuperview];
            }
            break;
        }
        case 2: //
        {
            if (self.tableView.superview == nil) {
                [_bottonView addSubview:self.tableView];
            }
            if (self.collectionView.superview) {
                [_collectionView removeFromSuperview];
            }
            [_tableView reloadData];
            break;
        }
        case 3: //
        {
            if (self.tableView.superview == nil) {
                [_bottonView addSubview:self.tableView];
            }
            if (self.collectionView.superview) {
                [_collectionView removeFromSuperview];
            }
            [_tableView reloadData];
            break;
        }

        default:
           
//            [self getMancuri:0];
            //            [self.tableView reloadData];
            break;
    }
    
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (_segementIndex == 2) {
        return 6;
    }
    else
    {
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (_segementIndex == 2) {
        return section%6+1;
    }
    else
    {
        return 6;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *norm_cell = @"morm_Cell";
    static NSString *pingLunCell = @"pingLunCell";
    if (_segementIndex == 2) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:norm_cell];
        if (cell==nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:norm_cell];
        }
        UIImage *icon = [UIImage imageNamed:@"person.png"];
        CGSize iconSize = CGSizeMake(30, 30);
        UIGraphicsBeginImageContextWithOptions(iconSize, NO, 0.0);
        CGRect rect = CGRectMake(0, 0, iconSize.width, iconSize.height);
        [icon drawInRect:rect];
        cell.imageView.image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        cell.textLabel.textColor = KLColor_ox(0x3e3a39);
        cell.textLabel.font = [UIFont systemFontOfSize:16];
        cell.textLabel.text = @"名字";
        
        return cell;
    }
    else
    {
        PingLunCell *cell = [tableView dequeueReusableCellWithIdentifier:pingLunCell];
        if (cell == nil) {
            cell = [[NSBundle mainBundle]loadNibNamed:@"PingLunCell" owner:self options:nil][0];
        }
        return cell;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (_segementIndex == 2) {
        return 20;
    }
    else
    {
        return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return _sectionMuArray[section];
}

#pragma mark getDistance
//- (double)getDistanceWithLongitude:(float)longitude latitude:(float)latitude
//{
//    //    float dis;
//    CLLocation *loca = [[CLLocation alloc]initWithLatitude:latitude longitude:longitude];
//    // 计算距离
//    CLLocationDistance meters=[_currentLoc distanceFromLocation:loca];
//    return meters/1000.0;
//}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_segementIndex == 2) {
        return 44;
    }
    else
    {
        return 116;
    }
}



#pragma mark UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    MakeupArtistViewController *manuMessVC = [[MakeupArtistViewController alloc]init];
//    MeiJIaShiListModel *mJSModel = _tabViewMuArray[indexPath.row];
//    manuMessVC.isMakeup = _isMakeup;
//    manuMessVC.userId = [mJSModel.mid intValue];
//    [self.navigationController pushViewController:manuMessVC animated:YES];
}

#pragma mark UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 14;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    SchoolCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:schoolCell forIndexPath:indexPath];
    

    return cell;
}

- (void)guanZhuBtnAct:(UIButton *)sender
{
    //    sender.selected = !sender.selected;
}

#pragma mark UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
//    DetailWorkController *detailWorkVC = [[DetailWorkController alloc]init];
//    detailWorkVC.workModel = _collectionMuArray[indexPath.row];
//    [self.navigationController pushViewController:detailWorkVC animated:YES];
}

#pragma mark CHTCollectionViewDelegateWaterfallLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(160, arc4random() % 50 + 200);
//    return CGSizeMake(100, 100);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
