//
//  DistrActivityViewController.m
//  驾轻松
//
//  Created by 李冬强 on 15/7/21.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "DistrActivityViewController.h"
#import "DisActMsgView.h"
#import "DisGeRMsgView.h"
#import "DisTopView.h"
@interface DistrActivityViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) DisActMsgView *activiView;
@property (nonatomic, strong) DisGeRMsgView *gerenMsgView;
@property (nonatomic, strong) DisTopView *topView;
@property (nonatomic, assign) NSInteger curentflag;
@property (nonatomic, strong) UIButton *nextBtn;
@end

@implementation DistrActivityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.navigationItem.title = @"发布活动";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"常见问题" style:UIBarButtonItemStylePlain target:self action:@selector(question)];
    [self initView];
}

- (void)initView
{
    _activiView = [DisActMsgView creatView];
    _gerenMsgView = [DisGeRMsgView creatView];
    [_activiView.selectImgBtn addTarget:self action:@selector(addUploadHeadClicked) forControlEvents:UIControlEventTouchUpInside];
    _topView = [DisTopView creatView];
    _topView.btn0.selected= YES;
    [_topView.btn0 addTarget:self action:@selector(topBtnAct:) forControlEvents:UIControlEventTouchUpInside];
    [_topView.btn1 addTarget:self action:@selector(topBtnAct:) forControlEvents:UIControlEventTouchUpInside];
    [_topView.btn2 addTarget:self action:@selector(topBtnAct:) forControlEvents:UIControlEventTouchUpInside];
    CGRect rect = CGRectMake(0, 0, kWidth, 100);
    _topView.frame = rect;
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kWidth, kHeight-49-kNavigtBarH) style:UITableViewStylePlain];
    _tableView.tableHeaderView = _topView;
    _tableView.tableFooterView = _activiView;
    
    [self.view addSubview:_tableView];
    _nextBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _nextBtn.frame = CGRectMake(0, kHeight-40, kWidth, 40);
    [_nextBtn setTitle:@"下一步" forState:UIControlStateNormal];
    [_nextBtn setBackgroundImage:[UIImage imageNamed:@"lan_btn_bg.png"] forState:UIControlStateNormal];
    [_nextBtn addTarget:self action:@selector(nextAct) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_nextBtn];
}

- (void)nextAct
{
    _curentflag++;
    if (_curentflag<=2) {
        [self resetBtnWith:_curentflag];
    }
    if (_curentflag==2)
    {
        _nextBtn.hidden = YES;
    }
}

- (void)resetBtnWith:(NSInteger)sta
{
    _curentflag = sta;
    _topView.btn0.selected = NO;
    _topView.btn1.selected = NO;
    _topView.btn2.selected = NO;
    if (sta==0)
    {
        _topView.btn0.selected = YES;
        _tableView.tableFooterView = _activiView;
    }
    if (sta==1)
    {
        _topView.btn1.selected = YES;
//        _tableView.hidden = NO;
        _tableView.tableFooterView = _gerenMsgView;
    }
    if (sta==2)
    {
        _topView.btn2.selected = YES;
//        _tableView.hidden = YES;
        _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
//    if (sender.tag==0)
//    {
//        
//    }
//    else if (sender.tag==1)
//    {
//        
//    }
//    else
//    {
//        
//        //        _tableView.tableHeaderView = nil;
//        //        _tableView.tableFooterView = nil;
//    }
}

- (void)question
{

}

- (void)addUploadHeadClicked
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil, nil];
    [actionSheet addButtonWithTitle:@"拍照"];
    [actionSheet addButtonWithTitle:@"从手机相册选择"];
    // 同时添加一个取消按钮
    [actionSheet addButtonWithTitle:@"取消"];
    // 将取消按钮的index设置成我们刚添加的那个按钮，这样在delegate中就可以知道是那个按钮
    actionSheet.destructiveButtonIndex = actionSheet.numberOfButtons - 1;
    [actionSheet showInView:self.view];
}


#pragma mark - 判断设备是否有摄像头

- (BOOL)isCameraAvailable
{
    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
}


#pragma mark - UIActionSheet delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.editing = YES;
    imagePicker.allowsEditing = YES;
    imagePicker.delegate = self;
    
    if (buttonIndex == 0)//照相机
    {
        if ([self isCameraAvailable]) {
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentModalViewController:imagePicker animated:YES];
        }else{
            //            [PublicMethod showMBProgressHUD:@"该设备没有摄像头" andWhereView:self.view hiddenTime:kHiddenTime];
        }
    }
    if (buttonIndex == 1)
    {
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentModalViewController:imagePicker animated:YES];
    }
    if (buttonIndex == 2)
    {
        
    }
    //    [imagePicker release];
}

#pragma mark - UIImagePicker delegate

//- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
//{
//    [picker dismissModalViewControllerAnimated:YES];
//    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
//    [self performSelector:@selector(saveImage:) withObject:image afterDelay:0.5];
//}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *_selectedImage = [[UIImage alloc] init];
    _selectedImage = info[@"UIImagePickerControllerOriginalImage"];
    
    NSData *data = UIImageJPEGRepresentation(_selectedImage, 0.5);
    // 这里base64Encoding 要修改
    //    NSString *baseStr = [data base64Encoding];
    //    NSLog(@"%@",baseStr);
    [self dismissViewControllerAnimated:YES completion:^{
        //        [self loadRequest:data];
    }];
    //    [self performSelector:@selector(loadRequest:) withObject:_selectedImage afterDelay:0.5];
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)topBtnAct:(UIButton *)sender
{
    [self resetBtnWith:sender.tag];
    
}
@end
