//
//  SchoolDetailViewController.m
//  驾轻松
//
//  Created by 李冬强 on 15/7/22.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "SchoolDetailViewController.h"
#import "UMSocial.h"
#import "CommentViewController.h"
@interface SchoolDetailViewController ()

@end

@implementation SchoolDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = KLColor(246, 246, 246);
    if (_vcFlag==1)
    {
        _nameLab.text = @"刘教练";
        _pricelab.text = @"80/天";
        _jianJieLab.text = @"教练简介";
    }
    if (_vcFlag==2)
    {
        _nameLab.text = @"刘陪教";
        _pricelab.text = @"160/天";
        _jianJieLab.text = @"教练简介";
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back:(UIButton *)sender
{
    if (sender.tag==0)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if(sender.tag==1)
    {
        [self share];
    }
    else
    {
        //liaotian
    }
        
}

- (void)share
{
    NSDictionary *dic = [[NSUserDefaults standardUserDefaults]objectForKey:kUserMsg];
    NSString *title = @"新融网";
    if (dic[@"name"]!=nil) {
        title = [NSString stringWithFormat:@"%@",dic[@"name"]];
    }
    NSString *url = @"http://www.baidu.com";
    if (url==nil)
    {
        url = @"https://www.xr58.com";
    }
    //微信和朋友圈
    [UMSocialData defaultData].extConfig.wechatSessionData.title = title;
    [UMSocialData defaultData].extConfig.wechatSessionData.url = url;
    //    [UMSocialData defaultData].extConfig.wechatTimelineData.title = [NSString stringWithFormat:@"%@  分享",title];
    [UMSocialData defaultData].extConfig.wechatTimelineData.url = url;
    
    [UMSocialData defaultData].extConfig.qqData.title = title;
    [UMSocialData defaultData].extConfig.qqData.url = url;
    [UMSocialData defaultData].extConfig.qzoneData.title = title;
    [UMSocialData defaultData].extConfig.qzoneData.url = url;
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:@"5542defa67e58ed9890060f8"
                                      shareText:[NSString stringWithFormat:@"随时随地，若有新融相伴，财富与惊喜随之而来。在这个股市动荡不定的时期，当所有人都说投资能赚多少钱的时候，而我们更关心你资金安全。新融网APP下载地址%@",url]
                                     shareImage:[UIImage imageNamed:@"logo_tu.png"]
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToWechatSession,UMShareToQQ,UMShareToSms,UMShareToQzone,UMShareToSina,UMShareToTencent,UMShareToWechatTimeline,UMShareToEmail,nil]
                                       delegate:self];
}
- (IBAction)btnAct:(UIButton *)sender
{
    CommentViewController *vc = [[CommentViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}
@end
