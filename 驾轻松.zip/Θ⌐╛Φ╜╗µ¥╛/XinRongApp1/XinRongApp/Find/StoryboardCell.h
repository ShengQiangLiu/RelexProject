//
//  CompanyInfoCell.h
//  XinRongApp
//
//  Created by 李冬强 on 15/5/2.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StoryboardCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end
