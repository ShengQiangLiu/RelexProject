//
//  HomeViewController.m
//  新融网
//
//  Created by 李冬强 on 15/7/17.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "HomeViewController.h"
#import "ActivityDetailViewController.h"
#import "FindCoachsViewController.h"
#import "FindSchoolViewController.h"
#import "FindTrainersViewController.h"
#import "DistrActivityViewController.h"
#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "KLCoverView.h"
#import "BWMCoverView.h"
#import "BWMCoverViewModel.h"
#import "MyButton.h"
#import "LeftBarView.h"
@interface HomeViewController ()
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *imagesMuArray;
@property (nonatomic, strong) BWMCoverView *topBanner;
@property (nonatomic, strong) LeftBarView *leftView;
@property (nonatomic, strong) UIView *coverView;

@property (nonatomic, strong) UIImageView *messageImg;
@property (nonatomic, strong) UIImageView *danWeiImg;
@property (nonatomic, assign) BOOL isShow;

@property (nonatomic, strong) NSArray *btnImages;
@property (nonatomic, strong) NSArray *btnTitles;
@property (nonatomic, strong) UIImageView *tipOfNew;

@property (nonatomic, strong) NSString *updataStr;
@property (nonatomic, strong) UIButton *leftBarButton;
@end

#define kTopH kHScare(180)


@implementation HomeViewController

- (id)initWithTitle:(NSString *)title withNavigationTitle:(NSString *)navTitle {
    
    if (self=[super init]) {
        // Custom initialization
        [[self tabBarItem] setImage:[UIImage imageNamed:@"homeIcon.png"]];
        self.view.backgroundColor = KLColor(233, 239, 241);
        self.title = title;
        self.navigationItem.title = navTitle;

    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _leftBarButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_leftBarButton setBackgroundImage:[UIImage imageNamed:@"home_mune.png"] forState:UIControlStateNormal];
    _leftBarButton.frame = CGRectMake(0, 0, 28, 28);
    [_leftBarButton addTarget:self action:@selector(muneshow) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:_leftBarButton];
//    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"home_mune.png"] style:UIBarButtonItemStylePlain target:self action:@selector(muneshow)];
    
    [self initData];
    [self addSubview];
//    [self addTableView];
    
    //检查更新
//    [self checkUpdata];
}

- (void)muneshow
{
    if (_isShow) {
        [UIView animateWithDuration:0.35 animations:^{
            _leftView.frame = CGRectMake(-110, 0, 110, kHeight-49-20);
            _leftBarButton.frame = CGRectMake(0, 0, 28, 28);
            CGAffineTransform t = CGAffineTransformMakeRotation(4.0f * M_PI);
            _leftBarButton.transform = t;
        }];
        _coverView.hidden = YES;
    }
    else
    {
        [UIView animateWithDuration:0.35 animations:^{
            _leftView.frame = CGRectMake(0, 0, 110, kHeight-49-20);
            [_leftBarButton setBackgroundImage:[UIImage imageNamed:@"home_mune.png"] forState:UIControlStateNormal];
//            _leftBarButton.frame = CGRectMake(0, 0, 63, 63);
//            CGAffineTransform t = CGAffineTransformMakeScale(2 * _leftBarButton.width,
//                                                             2 * _leftBarButton.height);
//            t = CGAffineTransformRotate(t, 2*M_1_PI);
            CGAffineTransform t = CGAffineTransformMakeRotation(3*M_PI);
            _leftBarButton.transform = t;
            _leftBarButton.frame = CGRectMake(0, 0, 63, 63);
        }];
        _coverView.hidden = NO;
    }
    _isShow=!_isShow;
}

- (void)goTo
{
    ActivityDetailViewController *vc = [[ActivityDetailViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)addSubview
{
    //rightBar
    UIView *rightbarView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 100, 30)];
//    rightbarView.backgroundColor = [UIColor grayColor];
    _messageImg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 23, 17)];
    _messageImg.image = [UIImage imageNamed:@"message_bai.png"];
    _messageImg.center = CGPointMake(rightbarView.width/6, rightbarView.height/2);
    [rightbarView addSubview:_messageImg];
    _danWeiImg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 25, 22)];
    _danWeiImg.image = [UIImage imageNamed:@"home_dw1.png"];
    _danWeiImg.center = CGPointMake(rightbarView.width/6*3+5, rightbarView.height/2);
    [rightbarView addSubview:_danWeiImg];
    UIImageView *moreImg = [[UIImageView alloc]initWithFrame:CGRectMake(rightbarView.width-14, (rightbarView.height-16)/2, 4, 16)];
    moreImg.image = [UIImage imageNamed:@"morerightbar.png"];
    [rightbarView addSubview:moreImg];
    
    for (int i=0; i<3; i++)
    {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(0, 0, i*rightbarView.width/3, rightbarView.height);
        btn.tag = i;
        [btn addTarget:self action:@selector(goTo) forControlEvents:UIControlEventTouchUpInside];
        [rightbarView addSubview:btn];
    }
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightbarView];
    
    
    [self addTableView];
    //左边菜单栏
    _coverView = [[UIView alloc]init];
    _coverView.backgroundColor = [UIColor grayColor];
    _coverView.alpha = 0.6;
    _coverView.frame = CGRectMake(0, 0, kWidth, kHeight);
    _coverView.hidden = YES;
    [_coverView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(muneshow)]];
    [self.view addSubview:_coverView];
    
    _leftView = [LeftBarView createView];
    _leftView.frame = CGRectMake(-110, 0, 110, kHeight-49);
    [_leftView.hindBtn addTarget:self action:@selector(leftViewAct:) forControlEvents:UIControlEventTouchUpInside];
    [_leftView.loginBtn addTarget:self action:@selector(leftViewAct:) forControlEvents:UIControlEventTouchUpInside];
    [_leftView.regieterBtn addTarget:self action:@selector(leftViewAct:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_leftView];
//    [[self getWindow] addSubview:_leftView];
}

- (UIWindow *)getWindow
{
    NSArray *windows = [UIApplication sharedApplication].windows;
    for (int i=0; i<windows.count; i++)
    {
        UIWindow *window = windows[i];
//        if (false==window.hidden) {
            if (window.frame.size.height>50)
            {
                return window;
            }
//        }
    }
    return NULL;
}

- (UIWindow *)getwindow1
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    if (!window) {
        window = [UIApplication sharedApplication].windows[0];
    }
    return window;
}

- (void)leftViewAct:(UIButton *)sender
{
    if (sender.tag==1)
    {
        LoginViewController *vc = [[LoginViewController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (sender.tag==2)
    {
        RegisterViewController *vc = [[RegisterViewController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    [self muneshow];
}

- (void)hideLeftView
{
    [UIView animateWithDuration:0.35 animations:^{
        _leftView.frame = CGRectMake(-110, 0, 110, kHeight-49);
    }];
    _isShow = NO;
    _coverView.hidden = YES;
}

- (void)viewWillAppear:(BOOL)animated
{
//    [self getBannerPic];
}

- (void)getBannerPic
{
    //    [SVProgressHUD showWithStatus:kLoadingData maskType:SVProgressHUDMaskTypeGradient];
//    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
//    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc]init];
//    //https请求方式设置
//    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
//    securityPolicy.allowInvalidCertificates = YES;
//    manager.securityPolicy = securityPolicy;
//    __weak typeof(self) weakSelf = self;
//    [manager POST:kqueryIndexPicUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        [weakSelf getBannerPicSuccess:responseObject];
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        MyLog(@"%@",error);
//        [SVProgressHUD dismiss];
//    }];
}

#pragma mark - 请求返回数据
- (void)getBannerPicSuccess:(id)response
{
    [SVProgressHUD dismiss];
    NSDictionary *dic = (NSDictionary *)response;
    MyLog(@"%@",dic);
    if ([dic[@"code"] isEqualToString:@"000"])
    {
        NSArray *data = dic[@"data"];
        //判断是否有图片
        if(data.count)
        {
            [_imagesMuArray removeAllObjects];
        }
        else
        {
            BWMCoverViewModel *model = [[BWMCoverViewModel alloc] initWithImageURLString:@"1.png" imageTitle:nil];
            BWMCoverViewModel *model1 = [[BWMCoverViewModel alloc] initWithImageURLString:@"1.png" imageTitle:nil];
            _imagesMuArray = [NSMutableArray arrayWithObjects:model,model1, nil];
        }
        for (int i = 0; i<data.count; i++)
        {
            NSString *imageStr = [NSString stringWithFormat:@"%@%@",kPicOrigUrl,data[i][@"filePath"]];
            //        NSString *imageTitle = [NSString stringWithFormat:@"第%d个小猫", i+1];
            BWMCoverViewModel *model = [[BWMCoverViewModel alloc] initWithImageURLString:imageStr imageTitle:nil];
            [_imagesMuArray addObject:model];
        }
        _topBanner.models = _imagesMuArray;
        //        _topBanner.placeholderImageNamed = BWMCoverViewDefaultImage;
        //        _topBanner.animationOption = UIViewAnimationOptionTransitionCurlUp;
        
        [_topBanner setCallBlock:^(NSInteger index) {
            NSLog(@"你点击了第%d个图片", index);
        }];
        
        //        [coverView2 setScrollViewCallBlock:^(NSInteger index) {
        //            NSLog(@"当前滚动到第%d个页面", index);
        //        }];
        
        
#warning 修改属性后必须调用updateView方法
        [_topBanner updateView];
    }
    else
    {
        //        [SVProgressHUD showInfoWithStatus:dic[@"msg"]];
    }
}

- (void)initData
{
    _btnImages = @[@"home_jxicon.png",@"home_jiaolian.png",@"home_plicon.png",@"home_hd_icon.png"];
    _btnTitles = @[@"找驾校",@"找教练",@"找陪练",@"活动发布",@"活动"];
    _imagesMuArray = [NSMutableArray array];
}

#pragma mark -添加列表视图
- (void)addTableView
{
    
    // 此数组用来保存BWMCoverViewModel
    NSMutableArray *realArray = [[NSMutableArray alloc] init];
    
    for (int i = 0; i<2; i++)
    {
        NSString *imageStr = [NSString stringWithFormat:@"http://www.xr58.com:8085/esb/apprequest/request?code=onlinePic&path=test/atta_banner_app_pic/2015518/3131431932392358.png"];
        //        NSString *imageTitle = [NSString stringWithFormat:@"第%d个小猫", i+1];
        BWMCoverViewModel *model = [[BWMCoverViewModel alloc] initWithImageURLString:imageStr imageTitle:nil];
        [realArray addObject:model];
    }
    
    // 以上代码只为了构建一个包含BWMCoverViewModel的数组而已——realArray
    //* 快速创建BWMCoverView
    // * models是一个包含BWMCoverViewModel的数组
    //* placeholderImageNamed为图片加载前的本地占位图片名
    
    _topBanner = [BWMCoverView coverViewWithModels:realArray andFrame:CGRectMake(0, kNavigtBarH, kWidth, (kTopH)) andPlaceholderImageNamed:@"huodong.png" andClickdCallBlock:^(NSInteger index) {
        NSLog(@"你点击了第%ld个图片", index);
        ActivityDetailViewController *vc = [[ActivityDetailViewController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }];
    [_topBanner setAutoPlayWithDelay:2.0];
    [self.view addSubview:_topBanner];
    
    //快捷入口
    UILabel *kuaiJieLab = [[UILabel alloc]initWithFrame:CGRectMake(10, kTopH, kWidth-100, kHScare(34))];
    kuaiJieLab.text = @"快捷入口";
    kuaiJieLab.font = [UIFont systemFontOfSize:12];
    kuaiJieLab.textColor = KLColor_ox(0x474c50);
    [self.view addSubview:kuaiJieLab];
    UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    moreBtn.frame = CGRectMake(kWidth-60, kTopH, 50, kuaiJieLab.height);
    [moreBtn setTitle:@"更多" forState:UIControlStateNormal];
    moreBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [moreBtn setTitleColor:KLColor_ox(0x3498db) forState:UIControlStateNormal];
    moreBtn.tag = 0;
    [moreBtn addTarget:self action:@selector(moreAct:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:moreBtn];
    
    CGFloat kuaiJieBtnW = (kWidth-3)/4;
    CGFloat kuaiJieBtnH = kHScare(60);
    for (int i=0; i<4; i++)
    {
        UIButton *kjBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        kjBtn.frame = CGRectMake(i*(kuaiJieBtnW+1), kuaiJieLab.bottom, kuaiJieBtnW, kuaiJieBtnH);
//        [moreBtn setTitle:@"更多" forState:UIControlStateNormal];
        kjBtn.tag = i+1;
        kjBtn.backgroundColor = [UIColor whiteColor];
        [kjBtn addTarget:self action:@selector(moreAct:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:kjBtn];
    }
    
    //考驾工具
    UILabel *gongJuLab = [[UILabel alloc]initWithFrame:CGRectMake(10, kuaiJieLab.bottom+kuaiJieBtnH, kWidth-100, kHScare(34))];
    gongJuLab.text = @"考驾工具";
    gongJuLab.font = [UIFont systemFontOfSize:12];
    gongJuLab.textColor = KLColor_ox(0x474c50);
    [self.view addSubview:gongJuLab];
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, gongJuLab.bottom, kWidth, kHeight-gongJuLab.bottom-49-64) style:UITableViewStylePlain];
    _tableView.backgroundColor = KLColor(233, 239, 241);
    //    _tableView.backgroundColor = KLColor(246, 246, 2);
    if (isOver3_5Inch)
    {
        //        CGRect rect = _allView.frame;
        //        _allView.frame = CGRectMake(0, 0, kWidth, kHScare(rect.size.height));
    }
    //    tableView.tableFooterView = _allView;
    [self.view addSubview:_tableView];
    CGFloat bottonW = (kWidth-2)/3.0;
    CGFloat bottonH = kHScare(60);
    UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, bottonW*(_btnImages.count/3?_btnImages.count/3:1))];
    _tableView.tableFooterView = footView;
    
    for (int i=0; i<_btnImages.count; i++)
    {
        MyButton *custBtn = [MyButton createView];
        custBtn.frame = CGRectMake(i%3*(bottonW+1), i/3*(bottonH+1), bottonW, bottonH);
        custBtn.imgView.image = [UIImage imageNamed:_btnImages[i]];
        custBtn.label.text = _btnTitles[i];
        custBtn.botton.tag = i;
//        if (i==5)
//        {
//            custBtn.bgImg.image = [UIImage imageNamed:@"more_h.png"];
//        }
        [custBtn.botton addTarget:self action:@selector(goTo:) forControlEvents:UIControlEventTouchUpInside];
        [footView addSubview:custBtn];
    }
}

- (void)moreAct:(UIButton *)sender
{

}

- (void)goTo:(UIButton *)sender
{
    //    return;
    switch (sender.tag)
    {
        case 0:
        {//找驾校
            FindSchoolViewController *vc = [[FindSchoolViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
        case 1:
        {//找教练
            FindCoachsViewController *vc = [[FindCoachsViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
        case 2:
        {//陪练
            FindTrainersViewController *vc = [[FindTrainersViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
        case 3:
        {//发布活动
            DistrActivityViewController *vc = [[DistrActivityViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
//        case 4:
//        {//活动
//            ActivityViewController *actiVC = [[ActivityViewController alloc]init];
//            [self.navigationController pushViewController:actiVC animated:YES];
//            break;
//        }
        default:
            break;
    }
}

#pragma mark - alertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==10000)
    {
        if (buttonIndex==1) {
            
            NSURL *url = [NSURL URLWithString:_updataStr];
            
            [[UIApplication sharedApplication]openURL:url];
            
        }
    }
}

#pragma mark 检查更新
- (void)checkUpdata
{
    //    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
    //    [parameter setObject:@"id" forKey:@"959293324"];
    //    [SVProgressHUD showWithStatus:@"检查更新中..." maskType:SVProgressHUDMaskTypeGradient];
    AFHTTPSessionManager *_manager = [[AFHTTPSessionManager alloc]init];
    [_manager POST:@"http://itunes.apple.com/lookup?id=1001047776" parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"%@", responseObject);
        [self verionback:responseObject];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@", error);
        [SVProgressHUD dismiss];
    }];
}

- (void)verionback:(id)response
{
    NSDictionary *dic = (NSDictionary *)response;
    MyLog(@"%@",dic);
    [SVProgressHUD dismiss];
    //    //    SBJsonParser *sbParser = [[SBJsonParser alloc]init];
    //    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:dic[@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    
    //CFShow((__bridge CFTypeRef)(infoDic));
    
    NSString *currentVersion = [infoDic objectForKey:@"CFBundleVersion"];
    NSLog(@"----%@----",currentVersion);
    
    NSArray *infoArray = [dic objectForKey:@"results"];
    
    if ([infoArray count]) {
        
        NSDictionary *releaseInfo = [infoArray objectAtIndex:0];
        
        NSString *lastVersion = [releaseInfo objectForKey:@"version"];
        _updataStr = [releaseInfo objectForKey:@"trackViewUrl"];
        [[NSUserDefaults standardUserDefaults]setObject:_updataStr forKey:kDownloadUrl];
        MyLog(@"%@",_updataStr);
        
        if (![lastVersion isEqualToString:currentVersion]) {
            
            //trackViewURL = [releaseInfo objectForKey:@"trackVireUrl"];
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"更新" message:@"有新的版本更新，是否前往更新？" delegate:self cancelButtonTitle:@"关闭" otherButtonTitles:@"更新", nil];
            
            alert.tag = 10000;
            
            [alert show];
            
        }
        else
        {
            
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
