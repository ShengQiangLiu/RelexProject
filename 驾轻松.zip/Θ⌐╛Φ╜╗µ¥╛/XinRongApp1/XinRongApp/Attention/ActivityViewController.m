//
//  ActivityViewController.m
//  驾轻松
//
//  Created by 李冬强 on 15/7/19.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "ActivityViewController.h"
#import "PicturesCollectionViewCell.h"
#import "SchoolDetailViewController.h"
@interface ActivityViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) UILabel *numTip;

@end

#define kItemW 250
#define kItemH 250
static NSString *reuseIdPicCell = @"PicturesCollectionViewCell";
#define ktipViewH 60
@implementation ActivityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = KLColor(246, 246, 246);
    [self initSubview];
}

- (void)initSubview
{
    UIView *tipView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, ktipViewH)];
    tipView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:tipView];
    
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(15, tipView.height/2-19/2, 19, 19)];
    imgView.image = [UIImage imageNamed:@"att_redtip.png"];
    _numTip = [[UILabel alloc]initWithFrame:imgView.bounds];
    _numTip.text = @"2";
    _numTip.textAlignment = NSTextAlignmentCenter;
    _numTip.font = [UIFont systemFontOfSize:12];
    [imgView addSubview:_numTip];
    [tipView addSubview:imgView];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(imgView.right+5, imgView.top, 100, imgView.height)];
    label.text = @"条新活动";
    label.font = [UIFont systemFontOfSize:10];
    [tipView addSubview:label];
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, ktipViewH, kWidth, kHeight-ktipViewH-49-kNavigtBarH) collectionViewLayout:flowLayout];
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    UINib *nib = [UINib nibWithNibName:reuseIdPicCell bundle:nil];
    [self.collectionView registerNib:nib forCellWithReuseIdentifier:reuseIdPicCell];
    self.collectionView.backgroundColor = KLColor(246, 246, 246);
    //    [_collectionView registerClass:[PicturesCollectionViewCell class] forCellWithReuseIdentifier:reuseIdPicCell];
    [self.view addSubview:_collectionView];
    
}


#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 2;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    PicturesCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdPicCell forIndexPath:indexPath];
//    ImageModel *result = _picArray[_selectInt][indexPath.row];
//    /*UIImage *image = [UIImage imageWithCGImage:[result thumbnail]];
//     NSString *fileName = [[result defaultRepresentation] filename];
//     NSURL *url = [[result defaultRepresentation] url];*/
//    ALAssetsLibrary *assetLibrary=[[ALAssetsLibrary alloc] init];
//    NSURL *url= result.imgUrl;
//    [assetLibrary assetForURL:url resultBlock:^(ALAsset *asset)  {
//        UIImage *image=[UIImage imageWithCGImage:asset.aspectRatioThumbnail];
//        cell.imageView.image=image;
//        cell.imgNameLab.text= result.imgName;
//        
//    }failureBlock:^(NSError *error) {
//        NSLog(@"error=%@",error);
//    }];
    //    NSString *imgURl = [kUrl stringByAppendingPathComponent:filePath];
    //    [cell.imageView sd_setImageWithURL:[NSURL URLWithString:imgURl] placeholderImage:[UIImage imageNamed:kLogo]];
    //    cell.imgNameLab.text = picDic[@"fileName"];
    return cell;
}

#pragma mark - UICollectionViewDelegateFlowLayout
// 定义每个Item的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((kWidth-3*11)/2 , 270);
}

// 定义每个UICollectionView的margin
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"\nitem:%ld\nsection:%ld\nrow:%ld", indexPath.item, indexPath.section, indexPath.row);
    SchoolDetailViewController *vc = [[SchoolDetailViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
//    NSDictionary *picDic = _picArray[_selectInt][indexPath.row];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
