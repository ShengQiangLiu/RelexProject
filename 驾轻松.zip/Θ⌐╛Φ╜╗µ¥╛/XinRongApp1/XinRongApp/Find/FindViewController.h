//
//  FindViewController.h
//  新融网
//
//  Created by 李冬强 on 15/7/17.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "ViewController.h"

@interface FindViewController : ViewController
- (id)initWithTitle:(NSString *)title withNavigationTitle:(NSString *)navTitle;
@end
