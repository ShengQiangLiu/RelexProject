//
//  CONSTS.h
//  艺甲名妆
//
//  Created by 李冬强 on 15-3-10.
//  Copyright (c) 2014年 ldq. All rights reserved.
//

#ifndef _____CONSTS_h
#define _____CONSTS_h

#ifdef DEBUG

#define MyLog(...) NSLog(__VA_ARGS__)

#else

#define MyLog(...)

#endif

#define kWidth ([UIScreen mainScreen].bounds.size.width)
#define kHeight ([UIScreen mainScreen].bounds.size.height)
//#define kNavigtBarH ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0?64:44)
#define kNavigtBarH (self.navigationController.navigationBar.bottom)
#define kHScare(x) (([UIScreen mainScreen].bounds.size.height*(x))/568)
#define kWScare(x) (([UIScreen mainScreen].bounds.size.width*(x))/320)

#import "UIImage+WB.h"
#import "UIBarButtonItem+WB.h"
#import "AFNetworking.h"
#import "SVProgressHUD.h"
#import "UIImageView+WebCache.h"
#import "UIViewExt.h"


// 判断是否为ios7
#define ios7 ([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0)
#define kVersion [[[UIDevice currentDevice] systemVersion] floatValue]

// 获得RGB颜色
#define KLColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]
#define KLColor_ox(rgbValue) \
                    [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16)) / 255.0 \
                    green:((float)((rgbValue & 0xFF00) >> 8)) / 255.0 \
                    blue :((float)(rgbValue & 0xFF)) / 255.0 alpha:1.0]
// 是否是4寸iPhone
// 是否是4寸iPhone
#define is4Inch ([UIScreen mainScreen].bounds.size.height == 568)
#define isOver3_5Inch ([UIScreen mainScreen].bounds.size.height > 480)

//#define STRONG_NONATOMIC_PROPERTY (@property (nonatomic, strong))
//#define ASSIGN_NONATOMIC_PROPERTY (@property (nonatomic, assign))
//#define WEAK_NONATOMIC_PROPERTY   (@property (nonatomic, weak))


#define kusername @"username"
#define kCustomerId @"customerId"
#define kIsRemembPsd @"isRemembPsd"
#define kUserMsg @"userMsg"

#define kDownloadUrl @"download"
#define kLogo @""
#define kLoadingData @""
#define kGetDataSuccess @""   //数据获取成功

#define kZhuTiColor KLColor(21, 98, 173)

//解锁
#define kpasscode @"passcode"
#define kgestureState @"gestureState"

//////接口//////

//测试
//#define kBaseUrl  @""
#define kUrl @"http://rap.jiaqingsong.com/v1/"

/*原始图片：http://123.56.151.61/t1/orig/
 启民★星  11:17:11
 略缩图：http://123.56.151.61/t1/s120/*/

//生产
//#define kUrl  @""


#define kBaseUrl  [kUrl stringByAppendingString:@""]

//获取图片
#define kPicOrigUrl  @"http://123.56.151.61/t1/orig/"
#define kPicSmlUrl  @"http://123.56.151.61/t1/s120/"


////////////个人中心/////////////////
//注册
#define kRegisterUrl  [kBaseUrl stringByAppendingString:@"userRegister"]

//获取验证码
//
#define ksendSMSUrl  [kBaseUrl stringByAppendingString:@"sendSMS"]

//获取school
#define kschoolsUrl  [kBaseUrl stringByAppendingString:@"schools"]

#endif
