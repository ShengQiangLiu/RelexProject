//
//  FindSchoolViewController.m
//  驾轻松
//
//  Created by 李冬强 on 15/7/21.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "FindCoachsViewController.h"
#import "CHTCollectionViewWaterfallLayout.h"
#import "FindCoachsCell.h"
#import "SchoolDetailViewController.h"
@interface FindCoachsViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,CHTCollectionViewDelegateWaterfallLayout>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) UILabel *poistionLab;
//workData
@property (nonatomic, strong) NSMutableArray *collectionMuArray;

@end

#define kCollectionCellSpace 6
#define kBottonH 49
static NSString *reuseIdPersonalWorkCell = @"FindCoachsCell";

@implementation FindCoachsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = KLColor(246, 246, 246);
    self.navigationItem.title = @"找教练";
    [self initData];
    [self initSubview];
}

- (void)initData
{
    _collectionMuArray = [NSMutableArray array];
}

- (void)initSubview
{
    //位置
    UIView *topView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWidth, 34)];
    [self.view addSubview:topView];
    topView.backgroundColor = [UIColor whiteColor];
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(10, (topView.height-16)/2, 12, 16)];
    imgView.image = [UIImage imageNamed:@"sch_poistion_lan.png"];
    [topView addSubview:imgView];
    
    _poistionLab = [[UILabel alloc]initWithFrame:CGRectMake(imgView.right+10, 0, kWidth-100, topView.height)];
    _poistionLab.text = @"中国";
    _poistionLab.font = [UIFont systemFontOfSize:12];
    _poistionLab.textColor = KLColor_ox(0x474c50);
    [topView addSubview:_poistionLab];
    
    UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    moreBtn.frame = CGRectMake(kWidth-60, 0, 50, topView.height);
    [moreBtn setTitle:@"更多" forState:UIControlStateNormal];
    moreBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [moreBtn setTitleColor:KLColor_ox(0x3498db) forState:UIControlStateNormal];
    moreBtn.tag = 0;
    [moreBtn addTarget:self action:@selector(moreAct:) forControlEvents:UIControlEventTouchUpInside];
    [topView addSubview:moreBtn];
    // 添加collectionwaterfalllayout
    [self addCollectionwaterfalllayout];
    
    // 注册collectionView nib
    UINib *nib = [UINib nibWithNibName:reuseIdPersonalWorkCell bundle:nil];
    [self.collectionView registerNib:nib forCellWithReuseIdentifier:reuseIdPersonalWorkCell];
}

- (void)moreAct:(UIButton *)sender
{
    
}


#pragma mark 添加collectionwaterfalllayout
- (void)addCollectionwaterfalllayout
{
    // 创建collectionView布局
    CHTCollectionViewWaterfallLayout *layout = [[CHTCollectionViewWaterfallLayout alloc] init];
    
    layout.sectionInset = UIEdgeInsetsMake(0, kCollectionCellSpace, kCollectionCellSpace, kCollectionCellSpace);
    
    layout.minimumColumnSpacing = kCollectionCellSpace;
    layout.minimumInteritemSpacing = kCollectionCellSpace;
    layout.columnCount = 2;
    
    UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, kCollectionCellSpace+34, kWidth, kHeight-kCollectionCellSpace) collectionViewLayout:layout];
    
    collectionView.delegate = self;
    collectionView.dataSource = self;
    collectionView.backgroundColor = KLColor(246, 246, 246);
    [self.view addSubview:collectionView];
    self.collectionView = collectionView;
}

#pragma mark UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //    return _collectionMuArray.count;
    return 10;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FindCoachsCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdPersonalWorkCell forIndexPath:indexPath];
    
    return cell;
}

#pragma mark UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    SchoolDetailViewController *detailVC = [[SchoolDetailViewController alloc]init];
    detailVC.vcFlag = 1;
    [self.navigationController pushViewController:detailVC animated:YES];
}

#pragma mark CHTCollectionViewDelegateWaterfallLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(100, 200+indexPath.row%2*20);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
