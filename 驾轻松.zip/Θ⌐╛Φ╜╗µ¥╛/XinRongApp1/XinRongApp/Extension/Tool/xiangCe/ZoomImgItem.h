//
//  ZoomImgItem.h
//  XinRongApp
//
//  Created by lidongqiang on 15-6-26.
//  Copyright (c) 2014年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KL_ImageZoomView.h"

@interface ZoomImgItem : UITableViewCell
{
    KL_ImageZoomView *imageView;
}

@property (nonatomic, retain)NSString *imgName;
@property (nonatomic, assign)CGSize size;

@end
