//
//  PersonDetailView.h
//  驾轻松
//
//  Created by 李冬强 on 15/7/18.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonDetailView : UIView
+ (instancetype)creatView;

@property (weak, nonatomic) IBOutlet UIButton *iconBtn;
@property (weak, nonatomic) IBOutlet UITextField *nameTF;
@property (weak, nonatomic) IBOutlet UITextField *iconTF;

@end
