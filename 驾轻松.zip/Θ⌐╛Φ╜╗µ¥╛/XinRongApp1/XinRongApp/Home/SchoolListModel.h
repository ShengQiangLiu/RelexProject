//
//  SchoolListModel.h
//  驾轻松
//
//  Created by 李冬强 on 15/7/27.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "BaseModel.h"

@interface SchoolListModel : BaseModel
@property (nonatomic, strong) NSString *_id;
@property (nonatomic, strong) NSString *address;
@property (nonatomic, strong) NSString *addtime;
@property (nonatomic, strong) NSString *contacts;
@property (nonatomic, strong) NSString *introduce;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSArray *pictureItmes;
@property (nonatomic, strong) NSString *price;
@property (nonatomic, strong) NSString *region;

@end
