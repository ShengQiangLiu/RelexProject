//
//  LoginViewController.h
//  XinRongApp
//
//  Created by 李冬强 on 15/3/10.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface LoginViewController : BaseViewController
@property (nonatomic, assign) NSInteger fromFlag;
- (IBAction)clearAct:(UIButton *)sender;

@end
