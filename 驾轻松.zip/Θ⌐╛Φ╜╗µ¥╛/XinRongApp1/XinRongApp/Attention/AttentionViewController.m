//
//  AttentionViewController.m
//  新融网
//
//  Created by 李冬强 on 15/7/17.
//  Copyright (c) 2015年 ldq. All rights reserved.
//

#import "AttentionViewController.h"
#import "ActivityViewController.h"
#import "LabelViewController.h"
#import "JiaYouViewController.h"
#import "TogetherViewController.h"

@interface AttentionViewController ()<ViewPagerDelegate,ViewPagerDataSource>
@property (nonatomic,strong) NSArray *titleArray;

@end

@implementation AttentionViewController

- (id)initWithTitle:(NSString *)title withNavigationTitle:(NSString *)navTitle {
    
    if (self=[super init]) {
        // Custom initialization
        [[self tabBarItem] setImage:[UIImage imageNamed:@"attentionIcon.png"]];
        
        self.title = title;
        self.navigationItem.title = navTitle;
        
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _titleArray = @[@"活动",@"标签",@"驾友",@"群组"];
//    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    self.delegate = self;
    self.dataSource = self;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"morerightbar.png"] style:UIBarButtonItemStylePlain target:self action:@selector(moreAct)];
}

- (void)moreAct
{
    [SVProgressHUD showInfoWithStatus:@"更多操作"];
}

#pragma mark - ViewPagerDataSource
- (NSUInteger)numberOfTabsForViewPager:(ViewPagerController *)viewPager {
    return _titleArray.count;
}

- (UIView *)viewPager:(ViewPagerController *)viewPager viewForTabAtIndex:(NSUInteger)index {
    
    UILabel *label = [UILabel new];
    label.backgroundColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:12.0];
    label.text = [NSString stringWithFormat:@"%@", _titleArray[index]];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    [label sizeToFit];
    
    return label;
}



#pragma mark - ViewPagerDataSource
- (UIViewController *)viewPager:(ViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index
{
    switch (index)
    {
        case 0:
        {
            ActivityViewController *actVC = [[ActivityViewController alloc]init];
            NSLog(@"%lu",(unsigned long)index);
//            actVC.view.backgroundColor = KLColor(4, 202, 202);
            return actVC;
            break;
        }
        case 1:
        {
            LabelViewController *actVC = [[LabelViewController alloc]init];
            NSLog(@"%lu",(unsigned long)index);
//            actVC.view.backgroundColor = KLColor(4, 202, 202);
            return actVC;
            break;
        }
        case 2:
        {
            JiaYouViewController *actVC = [[JiaYouViewController alloc]init];
            NSLog(@"%lu",(unsigned long)index);
//            actVC.view.backgroundColor = KLColor(4, 202, 202);
            return actVC;
            break;
        }
        case 3:
        {
            TogetherViewController *actVC = [[TogetherViewController alloc]init];
            NSLog(@"%lu",(unsigned long)index);
//            actVC.view.backgroundColor = KLColor(4, 202, 202);
            return actVC;
            break;
        }
        default:
        {
            ActivityViewController *actVC = [[ActivityViewController alloc]init];
            NSLog(@"%lu",(unsigned long)index);
            actVC.view.backgroundColor = KLColor(4, 202, 202);
            return actVC;
            break;
        }
    }
    
}

- (void)viewPager:(ViewPagerController *)viewPager didChangeTabToIndex:(NSUInteger)index {
    
    // Do something useful
}

#pragma mark - ViewPagerDelegate
- (CGFloat)viewPager:(ViewPagerController *)viewPager valueForOption:(ViewPagerOption)option withDefault:(CGFloat)value {
    
    switch (option) {
        case ViewPagerOptionStartFromSecondTab:
            return 0.0;
        case ViewPagerOptionCenterCurrentTab:
            return 0.0;
        case ViewPagerOptionTabLocation:
            return 1.0;
        case ViewPagerOptionTabHeight:
            return 42.0;
        case ViewPagerOptionTabOffset:
            return 0.0;
        case ViewPagerOptionTabWidth:
            return UIInterfaceOrientationIsLandscape(self.interfaceOrientation) ? 20 : kWidth/4;
        case ViewPagerOptionFixFormerTabsPositions:
            return 0.0;
        case ViewPagerOptionFixLatterTabsPositions://自动修正在后
            return 0.0;
        default:
            return value;
    }
}

- (UIColor *)viewPager:(ViewPagerController *)viewPager colorForComponent:(ViewPagerComponent)component withDefault:(UIColor *)color {
    
    switch (component) {
        case ViewPagerIndicator:
            return [kZhuTiColor colorWithAlphaComponent:0.64];
        case ViewPagerTabsView:
            
            //            return [[UIColor lightGrayColor] colorWithAlphaComponent:0.32];
        case ViewPagerContent:
            return [UIColor whiteColor];
            //            return [[UIColor darkGrayColor] colorWithAlphaComponent:0.32];
        default:
            return color;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
